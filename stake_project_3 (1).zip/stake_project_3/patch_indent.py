﻿import codecs

with codecs.open('dice_bot.py', 'r', 'utf-8-sig') as f:
    content = f.read()

content = content.replace('import inspect\n          print(f"   [DEBUG] Calling execute_async_script from:', '        import inspect\n        print(f"   [DEBUG] Calling execute_async_script from:')

with codecs.open('dice_bot.py', 'w', 'utf-8-sig') as f:
    f.write(content)
