﻿import codecs

with codecs.open('dice_bot.py', 'r', 'utf-8-sig') as f:
    content = f.read()

content = content.replace('result = self.driver.execute_async_script(script)', 'print("   [DEBUG] Calling execute_async_script...")\n        result = self.driver.execute_async_script(script)\n        print("   [DEBUG] execute_async_script returned!")')

with codecs.open('dice_bot.py', 'w', 'utf-8-sig') as f:
    f.write(content)
