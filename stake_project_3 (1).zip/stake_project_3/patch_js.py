﻿import codecs
import json

with codecs.open('dice_bot.py', 'r', 'utf-8-sig') as f:
    content = f.read()

old_js = \"\"\"          var callback = arguments[arguments.length - 1];
          fetch('/_api/graphql', {
              method: 'POST',
              headers: {
                  'content-type': 'application/json',
                  'x-access-token': '%s'
              },
              body: JSON.stringify(%s)
          }).then(r => r.json()).then(data => callback(JSON.stringify(data))).catch(e => callback("ERROR: " + e));\"\"\"

new_js = \"\"\"          var callback = arguments[arguments.length - 1];
          var timeout = setTimeout(function() { callback("ERROR: JS Fetch Timeout"); }, 8000);
          fetch('/_api/graphql', {
              method: 'POST',
              headers: {
                  'content-type': 'application/json',
                  'x-access-token': '%s'
              },
              body: JSON.stringify(%s)
          }).then(r => r.json()).then(data => { clearTimeout(timeout); callback(JSON.stringify(data)); }).catch(e => { clearTimeout(timeout); callback("ERROR: " + e); });\"\"\"

content = content.replace(old_js, new_js)

with codecs.open('dice_bot.py', 'w', 'utf-8-sig') as f:
    f.write(content)
