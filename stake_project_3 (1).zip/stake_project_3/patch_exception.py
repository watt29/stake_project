﻿import codecs

with codecs.open('dice_bot.py', 'r', 'utf-8-sig') as f:
    content = f.read()

content = content.replace('except Exception as e:\n                time.sleep(2 ** attempt)', 'except Exception as e:\n                print(f"   [!] EXCEPTION IN BETTING: {e}")\n                time.sleep(2 ** attempt)')

with codecs.open('dice_bot.py', 'w', 'utf-8-sig') as f:
    f.write(content)
