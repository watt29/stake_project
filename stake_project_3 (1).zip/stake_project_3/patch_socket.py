﻿import codecs

with codecs.open('dice_bot.py', 'r', 'utf-8-sig') as f:
    content = f.read()

if "import socket" not in content:
    content = "import socket\nsocket.setdefaulttimeout(30)\n" + content
    with codecs.open('dice_bot.py', 'w', 'utf-8-sig') as f:
        f.write(content)
    print("Socket timeout injected!")
