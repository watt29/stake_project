﻿import codecs
import base64

with codecs.open('dice_bot.py', 'r', 'utf-8-sig') as f:
    content = f.read()

old_js = base64.b64decode("          dmFyIGNhbGxiYWNrID0gYXJndW1lbnRzW2FyZ3VtZW50cy5sZW5ndGggLSAxXTsK          ZmV0Y2goJy9fYXBpL2dyYXBocWwnLCB7Ci              bWV0aG9kOiAnUE9TVCcsCi              aGVhZGVyczogewog                 J2NvbnRlbnQtdHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJywK                  J3gtYWNjZXNzLXRva2VuJzogJyVzJwog             fSwK              Ym9keTogSlNPTi5zdHJpbmdpZnkoJXMpCi          fSkudGhlbihyID0+IHIuanNvbigpKS50aGVuKGRhdGEgPT4gY2FsbGJhY2soSlNPTi5zdHJpbmdpZnkoZGF0YSkpKS5jYXRjaChlID0+IGNhbGxiYWNrKCJFUlJPUjogIiArIGUpOw==".replace(' ', '')).decode('utf-8')

new_js = base64.b64decode("          dmFyIGNhbGxiYWNrID0gYXJndW1lbnRzW2FyZ3VtZW50cy5sZW5ndGggLSAxXTsK          dmFyIHRpbWVvdXRJZCA9IHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7IGNhbGxiYWNrKCJFUlJPUjogSlMgRmV0Y2ggVGltZW91dCIpOyB9LCA4MDAwKTsK          ZmV0Y2goJy9fYXBpL2dyYXBocWwnLCB7Ci              bWV0aG9kOiAnUE9TVCcsCi              aGVhZGVyczogewog                 J2NvbnRlbnQtdHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJywK                  J3gtYWNjZXNzLXRva2VuJzogJyVzJwog             fSwK              Ym9keTogSlNPTi5zdHJpbmdpZnkoJXMpCi          fSkudGhlbihyID0+IHIuanNvbigpKS50aGVuKGRhdGEgPT4geyBjbGVhclRpbWVvdXQodGltZW91dElkKTsgY2FsbGJhY2soSlNPTi5zdHJpbmdpZnkoZGF0YSkpOyB9KS5jYXRjaChlID0+IHsgY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCk7IGNhbGxiYWNrKCJFUlJPUjogIiArIGUpOyB9KTs=".replace(' ', '')).decode('utf-8')

content = content.replace(old_js, new_js)

with codecs.open('dice_bot.py', 'w', 'utf-8-sig') as f:
    f.write(content)
