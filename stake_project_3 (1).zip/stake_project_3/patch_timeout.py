﻿import codecs

with codecs.open('dice_bot.py', 'r', 'utf-8-sig') as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if 'self.driver = uc.Chrome(' in line:
        lines.insert(i+1, "        self.driver.set_script_timeout(10)\n")
        break

with codecs.open('dice_bot.py', 'w', 'utf-8-sig') as f:
    f.writelines(lines)
