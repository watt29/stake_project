﻿import codecs

with codecs.open('dice_bot.py', 'r', 'utf-8-sig') as f:
    content = f.read()

content = content.replace('result = self._execute_graphql(query, variables=variables, operation_name=operation_name)', 'print(f"   [NET] Sending Bet Query (Attempt {attempt+1})...", end="\\r")\n                result = self._execute_graphql(query, variables=variables, operation_name=operation_name)')

with codecs.open('dice_bot.py', 'w', 'utf-8-sig') as f:
    f.write(content)
