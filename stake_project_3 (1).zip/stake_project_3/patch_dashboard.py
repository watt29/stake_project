﻿import codecs

with codecs.open('dice_bot.py', 'r', 'utf-8-sig') as f:
    content = f.read()

content = content.replace('if total_bets % 5 == 0:', 'if total_bets % 5 == 0 or not _bot_state.get("dashboard_initialized", False):')
content = content.replace('clear()', '_bot_state["dashboard_initialized"] = True\n                    clear()')

with codecs.open('dice_bot.py', 'w', 'utf-8-sig') as f:
    f.write(content)
