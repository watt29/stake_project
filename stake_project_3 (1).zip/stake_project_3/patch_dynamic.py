﻿import codecs

with codecs.open('dice_bot.py', 'r', 'utf-8') as f:
    content = f.read()

# Replace 1: def start_dice_bot
content = content.replace(
    'def start_dice_bot(self, base_bet, target=49.00, condition=\"below\"):',
    'def start_dice_bot(self, base_bet, target=49.00, condition=\"below\", dynamic_percent=0.0):'
)

# Replace 2: logic
logic_old = '''                # --- BET SIZING ---
                if virtual_mode:
                    current_bet = 0.0
                else:
                    current_bet = round(base_bet * (2 ** martingale_step), 8)'''

logic_new = '''                # --- BET SIZING ---
                if dynamic_percent > 0 and martingale_step == 0:
                    base_bet = round(balance * (dynamic_percent / 100), 8)
                    if base_bet < 0.0001:
                        base_bet = 0.0001
                        
                if virtual_mode:
                    current_bet = 0.0
                else:
                    current_bet = round(base_bet * (2 ** martingale_step), 8)'''

content = content.replace(logic_old, logic_new)

# Replace 3: __main__ parsing
main_old = '''    BASE_BET  = _bots.get("base_bet", 0.001)
    TARGET    = _bots.get("target", 49.00)
    CONDITION = _bots.get("condition", "below")'''

main_new = '''    BASE_BET  = _bots.get("base_bet", 0.001)
    DYNAMIC_PCT = _bots.get("dynamic_percent", 0.0)
    TARGET    = _bots.get("target", 49.00)
    CONDITION = _bots.get("condition", "below")'''

content = content.replace(main_old, main_new)

# Replace 4: __main__ calling
call_old = 'bot.start_dice_bot(base_bet=BASE_BET, target=TARGET, condition=CONDITION)'
call_new = 'bot.start_dice_bot(base_bet=BASE_BET, target=TARGET, condition=CONDITION, dynamic_percent=DYNAMIC_PCT)'

content = content.replace(call_old, call_new)

with codecs.open('dice_bot.py', 'w', 'utf-8') as f:
    f.write(content)
