﻿import codecs
import re

with codecs.open('dice_bot.py', 'r', 'utf-8-sig') as f:
    content = f.read()

pattern = re.compile(r"var callback = arguments\[arguments\.length - 1\];\s*fetch\('/_api/graphql', \{\s*method: 'POST',\s*headers: \{\s*'content-type': 'application/json',\s*'x-access-token': '%s'\s*\},\s*body: JSON\.stringify\(%s\)\s*\}\)\.then\(r => r\.json\(\)\)\.then\(data => callback\(JSON\.stringify\(data\)\)\)\.catch\(e => callback\(\"ERROR: \" \+ e\)\);")

new_js = "var callback = arguments[arguments.length - 1];\n          var timeoutId = setTimeout(function() { callback(\"ERROR: JS Fetch Timeout\"); }, 8000);\n          fetch('/_api/graphql', {\n              method: 'POST',\n              headers: {\n                  'content-type': 'application/json',\n                  'x-access-token': '%s'\n              },\n              body: JSON.stringify(%s)\n          }).then(r => r.json()).then(data => { clearTimeout(timeoutId); callback(JSON.stringify(data)); }).catch(e => { clearTimeout(timeoutId); callback(\"ERROR: \" + e); });"

if pattern.search(content):
    content = pattern.sub(new_js, content)
    with codecs.open('dice_bot.py', 'w', 'utf-8-sig') as f:
        f.write(content)
    print("Replaced with regex!")
else:
    print("Regex not found.")
