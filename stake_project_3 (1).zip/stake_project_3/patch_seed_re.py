﻿import codecs
import re

with codecs.open('dice_bot.py', 'r', 'utf-8-sig') as f:
    content = f.read()

pattern = re.compile(r'if data and data\.get\("rotateServerSeed"\):\s+self\.next_rotation_bet = self\.get_total_bets_from_stats\(\) \+ random\.randint\(800, 1500\)')

new_block = 'self.next_rotation_bet = self.get_total_bets_from_stats() + random.randint(800, 1500)\n            if data and data.get("rotateServerSeed"):'

if pattern.search(content):
    content = pattern.sub(new_block, content)
    with codecs.open('dice_bot.py', 'w', 'utf-8-sig') as f:
        f.write(content)
    print("Replaced!")
else:
    print("Not found.")
