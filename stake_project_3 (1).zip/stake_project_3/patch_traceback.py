﻿import codecs

with codecs.open('dice_bot.py', 'r', 'utf-8-sig') as f:
    content = f.read()

old_print = 'print("   [DEBUG] Calling execute_async_script...")'
new_print = 'import inspect\n          print(f"   [DEBUG] Calling execute_async_script from: {inspect.stack()[1].function} / {inspect.stack()[2].function}")'

if old_print in content:
    content = content.replace(old_print, new_print)
    with codecs.open('dice_bot.py', 'w', 'utf-8-sig') as f:
        f.write(content)
    print("Injected traceback!")
else:
    print("Not found.")
