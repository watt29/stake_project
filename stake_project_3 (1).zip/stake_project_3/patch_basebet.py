﻿import codecs

with codecs.open('dice_bot.py', 'r', 'utf-8-sig') as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if 'base_bet = 0.0003 + (session_wins * 0.000001)' in line:
        lines[i] = line.replace('base_bet = 0.0003 + (session_wins * 0.000001)', 'base_bet = 0.0003 # FIXED BASE BET')

with codecs.open('dice_bot.py', 'w', 'utf-8-sig') as f:
    f.writelines(lines)
