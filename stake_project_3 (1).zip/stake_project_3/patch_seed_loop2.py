﻿import codecs

with codecs.open('dice_bot.py', 'r', 'utf-8-sig') as f:
    content = f.read()

old_block = 'if data and data.get("rotateServerSeed"):\n                self.next_rotation_bet = self.get_total_bets_from_stats() + random.randint(800, 1500)'
new_block = 'self.next_rotation_bet = self.get_total_bets_from_stats() + random.randint(800, 1500)\n            if data and data.get("rotateServerSeed"):'

if old_block in content:
    content = content.replace(old_block, new_block)
    with codecs.open('dice_bot.py', 'w', 'utf-8-sig') as f:
        f.write(content)
    print("Replaced!")
else:
    print("Not found.")
