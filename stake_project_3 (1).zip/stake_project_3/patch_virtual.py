﻿import codecs

with codecs.open('dice_bot.py', 'r', 'utf-8-sig') as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if 'VIRTUAL PAUSE ENGAGED' in line:
        lines[i] = line.replace('5', '3')
    if 'VIRTUAL PAUSE</b>' in lines[i]:
        # the next line has the text
        pass
    if '!' in line and 'W-W-L' in line:
        lines[i] = line.replace('5', '3')

with codecs.open('dice_bot.py', 'w', 'utf-8-sig') as f:
    f.writelines(lines)
