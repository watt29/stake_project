﻿import codecs

with codecs.open('dice_bot.py', 'r', 'utf-8-sig') as f:
    content = f.read()

content = content.replace('err_msg = str(result["errors"][0].get("message", ""))', 'err_msg = str(result["errors"][0].get("message", ""))\n                      if "JS Fetch Timeout" in err_msg:\n                          print(f"   [!] Cloudflare blocked the bet. Retrying...", end="\\r")\n                          time.sleep(2)\n                          continue')

with codecs.open('dice_bot.py', 'w', 'utf-8-sig') as f:
    f.write(content)
