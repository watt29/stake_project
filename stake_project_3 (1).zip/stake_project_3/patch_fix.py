﻿import codecs

with codecs.open('dice_bot.py', 'r', 'utf-8-sig') as f:
    content = f.read()

content = content.replace('_bot_state["dashboard_initialized"] = True\n                    clear()', 'clear()')
content = content.replace('def _bot_state["dashboard_initialized"] = True\n                    clear():', 'def clear():')

with codecs.open('dice_bot.py', 'w', 'utf-8-sig') as f:
    f.write(content)
